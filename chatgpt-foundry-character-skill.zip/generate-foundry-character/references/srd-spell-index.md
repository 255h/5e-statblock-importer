# Проверенные названия заклинаний SRD 5.1

Источник: https://github.com/palikhov/srd-dnd-5e-ru

Версия: `07425b6e88e41e8b72868b87fccbd42c5bb2711d`. Извлечено из `docs/spellcasting/spells/*.md`, поля `name` и `level`. Это сохранённая сверка с базой, не утверждение о текущей версии сайта. Для свежих изменений проверь исходную запись.

| English name | Level | Source file |
| --- | --- | --- |
| Acid Arrow | 2 | `acid_arrow.md` |
| Acid Splash | 0 | `acid_splash.md` |
| Aid | 2 | `aid.md` |
| Alarm | 1 | `alarm.md` |
| Alter Self | 2 | `alter_self.md` |
| Animal Friendship | 1 | `animal_friendship.md` |
| Animal Messenger | 2 | `animal_messenger.md` |
| Animal Shapes | 8 | `animal_shapes.md` |
| Animate Dead | 3 | `animate_dead.md` |
| Animate Objects | 5 | `animate_objects.md` |
| Antilife Shell | 5 | `antilife_shell.md` |
| Antimagic Field | 8 | `antimagic_field.md` |
| Antipathy/Sympathy | 8 | `antipathysympathy.md` |
| Arcane Eye | 4 | `arcane_eye.md` |
| Arcane Hand | 5 | `arcane_hand.md` |
| Arcane Lock | 2 | `arcane_lock.md` |
| Arcane Sword | 7 | `arcane_sword.md` |
| Arcanist's Magic Aura | 2 | `arcanists_magic_aura.md` |
| Astral Projection | 9 | `astral_projection.md` |
| Augury | 2 | `augury.md` |
| Awaken | 5 | `awaken.md` |
| Bane | 1 | `bane.md` |
| Banishment | 4 | `banishment.md` |
| Barkskin | 2 | `barkskin.md` |
| Beacon of Hope | 3 | `beacon_of_hope.md` |
| Bestow Curse | 3 | `bestow_curse.md` |
| Black Tentacles | 4 | `black_tentacles.md` |
| Blade Barrier | 6 | `blade_barrier.md` |
| Bless | 1 | `bless.md` |
| Blight | 4 | `blight.md` |
| Blindness/Deafness | 2 | `blindnessdeafness.md` |
| Blink | 3 | `blink.md` |
| Blur | 2 | `blur.md` |
| Branding Smite | 2 | `branding_smite.md` |
| Burning Hands | 1 | `burning_hands.md` |
| Call Lightning | 3 | `call_lightning.md` |
| Calm Emotions | 2 | `calm_emotions.md` |
| Chain Lightning | 6 | `chain_lightning.md` |
| Charm Person | 1 | `charm_person.md` |
| Chill Touch | 0 | `chill_touch.md` |
| Circle of Death | 6 | `circle_of_death.md` |
| Clairvoyance | 3 | `clairvoyance.md` |
| Clone | 8 | `clone.md` |
| Cloudkill | 5 | `cloudkill.md` |
| Color Spray | 1 | `color_spray.md` |
| Command | 1 | `command.md` |
| Commune | 5 | `commune.md` |
| Commune with Nature | 5 | `commune_with_nature.md` |
| Comprehend Languages | 1 | `comprehend_languages.md` |
| Compulsion | 4 | `compulsion.md` |
| Cone of Cold | 5 | `cone_of_cold.md` |
| Confusion | 4 | `confusion.md` |
| Conjure Animals | 3 | `conjure_animals.md` |
| Conjure Celestial | 7 | `conjure_celestial.md` |
| Conjure Elemental | 5 | `conjure_elemental.md` |
| Conjure Fey | 6 | `conjure_fey.md` |
| Conjure Minor Elementals | 4 | `conjure_minor_elementals.md` |
| Conjure Woodland Beings | 4 | `conjure_woodland_beings.md` |
| Contact Other Plane | 5 | `contact_other_plane.md` |
| Contagion | 5 | `contagion.md` |
| Contingency | 6 | `contingency.md` |
| Continual Flame | 2 | `continual_flame.md` |
| Control Water | 4 | `control_water.md` |
| Control Weather | 8 | `control_weather.md` |
| Counterspell | 3 | `counterspell.md` |
| Create Food and Water | 3 | `create_food_and_water.md` |
| Create or Destroy Water | 1 | `create_or_destroy_water.md` |
| Create Undead | 6 | `create_undead.md` |
| Creation | 5 | `creation.md` |
| Cure Wounds | 1 | `cure_wounds.md` |
| Dancing Lights | 0 | `dancing_lights.md` |
| Darkness | 2 | `darkness.md` |
| Darkvision | 2 | `darkvision.md` |
| Daylight | 3 | `daylight.md` |
| Death Ward | 4 | `death_ward.md` |
| Delayed Blast Fireball | 7 | `delayed_blast_fireball.md` |
| Demiplane | 8 | `demiplane.md` |
| Detect Evil and Good | 1 | `detect_evil_and_good.md` |
| Detect Magic | 1 | `detect_magic.md` |
| Detect Poison and Disease | 1 | `detect_poison_and_disease.md` |
| Detect Thoughts | 2 | `detect_thoughts.md` |
| Dimension Door | 4 | `dimension_door.md` |
| Disguise Self | 1 | `disguise_self.md` |
| Disintegrate | 6 | `disintegrate.md` |
| Dispel Evil and Good | 5 | `dispel_evil_and_good.md` |
| Dispel Magic | 3 | `dispel_magic.md` |
| Divination | 4 | `divination.md` |
| Divine Favor | 1 | `divine_favor.md` |
| Divine Word | 7 | `divine_word.md` |
| Dominate Beast | 4 | `dominate_beast.md` |
| Dominate Monster | 8 | `dominate_monster.md` |
| Dominate Person | 5 | `dominate_person.md` |
| Dream | 5 | `dream.md` |
| Druidcraft | 0 | `druidcraft.md` |
| Earthquake | 8 | `earthquake.md` |
| Eldritch Blast | 0 | `eldritch_blast.md` |
| Enhance Ability | 2 | `enhance_ability.md` |
| Enlarge/Reduce | 2 | `enlargereduce.md` |
| Entangle | 1 | `entangle.md` |
| Enthrall | 2 | `enthrall.md` |
| Etherealness | 7 | `etherealness.md` |
| Expeditious Retreat | 1 | `expeditious_retreat.md` |
| Eyebite | 6 | `eyebite.md` |
| Fabricate | 4 | `fabricate.md` |
| Faerie Fire | 1 | `faerie_fire.md` |
| Faithful Hound | 4 | `faithful_hound.md` |
| False Life | 1 | `false_life.md` |
| Fear | 3 | `fear.md` |
| Feather Fall | 1 | `feather_fall.md` |
| Feeblemind | 8 | `feeblemind.md` |
| Find Familiar | 1 | `find_familiar.md` |
| Find Steed | 2 | `find_steed.md` |
| Find the Path | 6 | `find_the_path.md` |
| Find Traps | 2 | `find_traps.md` |
| Finger of Death | 7 | `finger_of_death.md` |
| Fire Bolt | 0 | `fire_bolt.md` |
| Fire Shield | 4 | `fire_shield.md` |
| Fire Storm | 7 | `fire_storm.md` |
| Fireball | 3 | `fireball.md` |
| Flame Blade | 2 | `flame_blade.md` |
| Flame Strike | 5 | `flame_strike.md` |
| Flaming Sphere | 2 | `flaming_sphere.md` |
| Flesh to Stone | 6 | `flesh_to_stone.md` |
| Floating Disk | 1 | `floating_disk.md` |
| Fly | 3 | `fly.md` |
| Fog Cloud | 1 | `fog_cloud.md` |
| Forbiddance | 6 | `forbiddance.md` |
| Forcecage | 7 | `forcecage.md` |
| Foresight | 9 | `foresight.md` |
| Freedom of Movement | 4 | `freedom_of_movement.md` |
| Freezing Sphere | 6 | `freezing_sphere.md` |
| Gaseous Form | 3 | `gaseous_form.md` |
| Gate | 9 | `gate.md` |
| Geas | 5 | `geas.md` |
| Gentle Repose | 2 | `gentle_repose.md` |
| Giant Insect | 4 | `giant_insect.md` |
| Glibness | 8 | `glibness.md` |
| Globe of Invulnerability | 6 | `globe_of_invulnerability.md` |
| Glyph of Warding | 3 | `glyph_of_warding.md` |
| Goodberry | 1 | `goodberry.md` |
| Grease | 1 | `grease.md` |
| Greater Invisibility | 4 | `greater_invisibility.md` |
| Greater Restoration | 5 | `greater_restoration.md` |
| Guardian of Faith | 4 | `guardian_of_faith.md` |
| Guards and Wards | 6 | `guards_and_wards.md` |
| Guidance | 0 | `guidance.md` |
| Guiding Bolt | 1 | `guiding_bolt.md` |
| Gust of Wind | 2 | `gust_of_wind.md` |
| Hallow | 5 | `hallow.md` |
| Hallucinatory Terrain | 4 | `hallucinatory_terrain.md` |
| Harm | 6 | `harm.md` |
| Haste | 3 | `haste.md` |
| Heal | 6 | `heal.md` |
| Healing Word | 1 | `healing_word.md` |
| Heat Metal | 2 | `heat_metal.md` |
| Hellish Rebuke | 1 | `hellish_rebuke.md` |
| Heroes' Feast | 6 | `heroes_feast.md` |
| Heroism | 1 | `heroism.md` |
| Hideous Laughter | 1 | `hideous_laughter.md` |
| Hold Monster | 5 | `hold_monster.md` |
| Hold Person | 2 | `hold_person.md` |
| Holy Aura | 8 | `holy_aura.md` |
| Hunter's Mark | 1 | `hunters_mark.md` |
| Hypnotic Pattern | 3 | `hypnotic_pattern.md` |
| Ice Storm | 4 | `ice_storm.md` |
| Identify | 1 | `identify.md` |
| Illusory Script | 1 | `illusory_script.md` |
| Imprisonment | 9 | `imprisonment.md` |
| Incendiary Cloud | 8 | `incendiary_cloud.md` |
| Inflict Wounds | 1 | `inflict_wounds.md` |
| Insect Plague | 5 | `insect_plague.md` |
| Instant Summons | 6 | `instant_summons.md` |
| Invisibility | 2 | `invisibility.md` |
| Irresistible Dance | 6 | `irresistible_dance.md` |
| Jump | 1 | `jump.md` |
| Knock | 2 | `knock.md` |
| Legend Lore | 5 | `legend_lore.md` |
| Lesser Restoration | 2 | `lesser_restoration.md` |
| Levitate | 2 | `levitate.md` |
| Light | 0 | `light.md` |
| Lightning Bolt | 3 | `lightning_bolt.md` |
| Locate Animals or Plants | 2 | `locate_animals_or_plants.md` |
| Locate Creature | 4 | `locate_creature.md` |
| Locate Object | 2 | `locate_object.md` |
| Longstrider | 1 | `longstrider.md` |
| Mage Armor | 1 | `mage_armor.md` |
| Mage Hand | 0 | `mage_hand.md` |
| Magic Circle | 3 | `magic_circle.md` |
| Magic Jar | 6 | `magic_jar.md` |
| Magic Missile | 1 | `magic_missile.md` |
| Magic Mouth | 2 | `magic_mouth.md` |
| Magic Weapon | 2 | `magic_weapon.md` |
| Magnificent Mansion | 7 | `magnificent_mansion.md` |
| Major Image | 3 | `major_image.md` |
| Mass Cure Wounds | 5 | `mass_cure_wounds.md` |
| Mass Heal | 9 | `mass_heal.md` |
| Mass Healing Word | 3 | `mass_healing_word.md` |
| Mass Suggestion | 6 | `mass_suggestion.md` |
| Maze | 8 | `maze.md` |
| Meld into Stone | 3 | `meld_into_stone.md` |
| Mending | 0 | `mending.md` |
| Message | 0 | `message.md` |
| Meteor Swarm | 9 | `meteor_swarm.md` |
| Mind Blank | 8 | `mind_blank.md` |
| Minor Illusion | 0 | `minor_illusion.md` |
| Mirage Arcane | 7 | `mirage_arcane.md` |
| Mirror Image | 2 | `mirror_image.md` |
| Mislead | 5 | `mislead.md` |
| Misty Step | 2 | `misty_step.md` |
| Modify Memory | 5 | `modify_memory.md` |
| Moonbeam | 2 | `moonbeam.md` |
| Move Earth | 6 | `move_earth.md` |
| Nondetection | 3 | `nondetection.md` |
| Pass without Trace | 2 | `pass_without_trace.md` |
| Passwall | 5 | `passwall.md` |
| Phantasmal Killer | 4 | `phantasmal_killer.md` |
| Phantom Steed | 3 | `phantom_steed.md` |
| Planar Ally | 6 | `planar_ally.md` |
| Planar Binding | 5 | `planar_binding.md` |
| Plane Shift | 7 | `plane_shift.md` |
| Plant Growth | 3 | `plant_growth.md` |
| Poison Spray | 0 | `poison_spray.md` |
| Polymorph | 4 | `polymorph.md` |
| Power Word Kill | 9 | `power_word_kill.md` |
| Power Word Stun | 8 | `power_word_stun.md` |
| Prayer of Healing | 2 | `prayer_of_healing.md` |
| Prestidigitation | 0 | `prestidigitation.md` |
| Prismatic Spray | 7 | `prismatic_spray.md` |
| Prismatic Wall | 9 | `prismatic_wall.md` |
| Private Sanctum | 4 | `private_sanctum.md` |
| Produce Flame | 0 | `produce_flame.md` |
| Programmed Illusion | 6 | `programmed_illusion.md` |
| Project Image | 7 | `project_image.md` |
| Protection from Energy | 3 | `protection_from_energy.md` |
| Protection from Evil and Good | 1 | `protection_from_evil_and_good.md` |
| Protection from Poison | 2 | `protection_from_poison.md` |
| Purify Food and Drink | 1 | `purify_food_and_drink.md` |
| Raise Dead | 5 | `raise_dead.md` |
| Ray of Enfeeblement | 2 | `ray_of_enfeeblement.md` |
| Ray of Frost | 0 | `ray_of_frost.md` |
| Regenerate | 7 | `regenerate.md` |
| Reincarnate | 5 | `reincarnate.md` |
| Remove Curse | 3 | `remove_curse.md` |
| Resilient Sphere | 4 | `resilient_sphere.md` |
| Resistance | 0 | `resistance.md` |
| Resurrection | 7 | `resurrection.md` |
| Reverse Gravity | 7 | `reverse_gravity.md` |
| Revivify | 3 | `revivify.md` |
| Rope Trick | 2 | `rope_trick.md` |
| Sacred Flame | 0 | `sacred_flame.md` |
| Sanctuary | 1 | `sanctuary.md` |
| Scorching Ray | 2 | `scorching_ray.md` |
| Scrying | 5 | `scrying.md` |
| Secret Chest | 4 | `secret_chest.md` |
| See Invisibility | 2 | `see_invisibility.md` |
| Seeming | 5 | `seeming.md` |
| Sending | 3 | `sending.md` |
| Sequester | 7 | `sequester.md` |
| Shapechange | 9 | `shapechange.md` |
| Shatter | 2 | `shatter.md` |
| Shield | 1 | `shield.md` |
| Shield of Faith | 1 | `shield_of_faith.md` |
| Shillelagh | 0 | `shillelagh.md` |
| Shocking Grasp | 0 | `shocking_grasp.md` |
| Silence | 2 | `silence.md` |
| Silent Image | 1 | `silent_image.md` |
| Simulacrum | 7 | `simulacrum.md` |
| Sleep | 1 | `sleep.md` |
| Sleet Storm | 3 | `sleet_storm.md` |
| Slow | 3 | `slow.md` |
| Spare the Dying | 0 | `spare_the_dying.md` |
| Speak with Animals | 1 | `speak_with_animals.md` |
| Speak with Dead | 3 | `speak_with_dead.md` |
| Speak with Plants | 3 | `speak_with_plants.md` |
| Spider Climb | 2 | `spider_climb.md` |
| Spike Growth | 2 | `spike_growth.md` |
| Spirit Guardians | 3 | `spirit_guardians.md` |
| Spiritual Weapon | 2 | `spiritual_weapon.md` |
| Stinking Cloud | 3 | `stinking_cloud.md` |
| Stone Shape | 4 | `stone_shape.md` |
| Stoneskin | 4 | `stoneskin.md` |
| Storm of Vengeance | 9 | `storm_of_vengeance.md` |
| Suggestion | 2 | `suggestion.md` |
| Sunbeam | 6 | `sunbeam.md` |
| Sunburst | 8 | `sunburst.md` |
| Symbol | 7 | `symbol.md` |
| Telekinesis | 5 | `telekinesis.md` |
| Telepathic Bond | 5 | `telepathic_bond.md` |
| Teleport | 7 | `teleport.md` |
| Teleportation Circle | 5 | `teleportation_circle.md` |
| Thaumaturgy | 0 | `thaumaturgy.md` |
| Thunderwave | 1 | `thunderwave.md` |
| Time Stop | 9 | `time_stop.md` |
| Tiny Hut | 3 | `tiny_hut.md` |
| Tongues | 3 | `tongues.md` |
| Transport via Plants | 6 | `transport_via_plants.md` |
| Tree Stride | 5 | `tree_stride.md` |
| True Polymorph | 9 | `true_polymorph.md` |
| True Resurrection | 9 | `true_resurrection.md` |
| True Seeing | 6 | `true_seeing.md` |
| True Strike | 0 | `true_strike.md` |
| Unseen Servant | 1 | `unseen_servant.md` |
| Vampiric Touch | 3 | `vampiric_touch.md` |
| Vicious Mockery | 0 | `vicious_mockery.md` |
| Wall of Fire | 4 | `wall_of_fire.md` |
| Wall of Force | 5 | `wall_of_force.md` |
| Wall of Ice | 6 | `wall_of_ice.md` |
| Wall of Stone | 5 | `wall_of_stone.md` |
| Wall of Thorns | 6 | `wall_of_thorns.md` |
| Warding Bond | 2 | `warding_bond.md` |
| Water Breathing | 3 | `water_breathing.md` |
| Water Walk | 3 | `water_walk.md` |
| Web | 2 | `web.md` |
| Weird | 9 | `weird.md` |
| Wind Walk | 6 | `wind_walk.md` |
| Wind Wall | 3 | `wind_wall.md` |
| Wish | 9 | `wish.md` |
| Word of Recall | 6 | `word_of_recall.md` |
| Zone of Truth | 2 | `zone_of_truth.md` |
